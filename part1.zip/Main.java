public class Main {
    public static void main(String[] args) {
        System.out.println("hello java");
        // 計算する
        System.out.println(10 + 10);
        // 変数で計算してみよう
        int x = 1;
        int y = 2;
        int z = 3;
        System.out.println(z);

        System.out.println(x + y + z);
        // 演算子
        /*
         * 足し算 +
         * 引き算 -
         * 掛け算 *
         * 割り算 /
         * 剰余 %(余りのこと)
         */

        // 条件分岐
        int JOUKEN = 4;
        if (JOUKEN == 1) {
            System.out.println("JOUKENは1です");
        } else if (JOUKEN == 3) {
            System.out.println("JOUKENは3です");
        } else if (JOUKEN == 4) {
            System.out.println("JOUKENは4です");
        } else {
            System.out.println("条件は1ではありません");
        }
        // 繰り返し処理
        // for文
        for (int For = 1; For < 10; For++) {
            System.out.println(For);
            if (For == 10) {
                System.out.println("Forが10になりました。");
                break;// 10になると繰り返し処理を中止する
            }
        }
        // swich文
        int SWI = 3;
        switch (SWI) {
            case 1: // 最後が;ではなく:
                System.out.println("SWIは1です");
                break;

            case 2:
                System.out.println("SWIは2です");
                break;

            case 3:
                System.out.println("SWIは3です");
                break;
        }
        
    }
}